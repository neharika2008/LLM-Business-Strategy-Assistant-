from openai import OpenAI

client = OpenAI()

response = client.chat.completions.create(
    model="gpt-4",
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "What is SWOT analysis?"}
    ],
    max_tokens=800
)

print(response.choices[0].message.content)


























