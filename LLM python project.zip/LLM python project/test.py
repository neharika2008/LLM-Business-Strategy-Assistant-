import streamlit as st
import openai
import os
from dotenv import load_dotenv

# Load OpenAI API key
load_dotenv()
openai.api_key = os.getenv("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)")

# Streamlit UI
st.set_page_config(page_title="LLM Business Strategy Assistant", layout="centered")
st.title("🤖 LLM-Based Business Strategy Assistant")
st.markdown("Enter your **SWOT** analysis and business **Goal** to generate GTM, marketing, and roadmap strategies.")

# Input fields
with st.form("strategy_form"):
    strengths = st.text_area("💪 Strengths", "")
    weaknesses = st.text_area("🔻 Weaknesses", "")
    opportunities = st.text_area("📈 Opportunities", "")
    threats = st.text_area("⚠️ Threats", "")
    goal = st.text_area("🎯 Business Goal", "")
    submitted = st.form_submit_button("Generate Strategy")

# Function to query GPT
def generate_strategy(strengths, weaknesses, opportunities, threats, goal):
    prompt = f"""
You are a Business Strategy Assistant AI. Based on the following SWOT analysis and business goal, generate:
1. Go-To-Market (GTM) Strategy
2. Marketing Strategy
3. Product Roadmap (if applicable)

SWOT:
- Strengths: {strengths}
- Weaknesses: {weaknesses}
- Opportunities: {opportunities}
- Threats: {threats}

Goal: {goal}
"""
    response = openai.ChatCompletion.create(
        model="gpt-4",  # use "gpt-3.5-turbo" if you're on free tier
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7,
        max_tokens=800
    )
    return response.choices[0].message["content"]

# Display output
if submitted:
    if all([strengths, weaknesses, opportunities, threats, goal]):
        with st.spinner("Generating strategy..."):
            output = generate_strategy(strengths, weaknesses, opportunities, threats, goal)
            st.success("✅ Strategy Generated")
            st.markdown("### 🧠 AI Strategy Output")
            st.code(output, language='markdown')
    else:
        st.warning("⚠️ Please fill out all fields before submitting.")